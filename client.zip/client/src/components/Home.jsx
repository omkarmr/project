import Hero from "./Hero"

const Home = () => {
    return (
        <Hero />
    )
}

export default Home